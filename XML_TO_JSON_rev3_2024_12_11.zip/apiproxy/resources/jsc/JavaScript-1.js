 var requestPayload = context.getVariable("request.content");
 var xmlrequest = requestPayload.toString();
 context.setVariable("xmlrequest",xmlrequest);  var requestPayload = context.getVariable("request.content");
 var xmlrequest = requestPayload.toString();
 context.setVariable("xmlrequest",xmlrequest);