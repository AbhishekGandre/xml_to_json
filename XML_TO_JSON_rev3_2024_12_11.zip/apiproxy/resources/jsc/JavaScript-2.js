var requestPayload = context.getVariable("jsonData");
 context.setVariable("request.content",requestPayload);  
